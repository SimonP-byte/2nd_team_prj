'''
  My Rpi STD Lib
  
  Hp    : 010-2402-4398
  Name  : 송 명 규
  Email : mgsong@hanmail.net
  V1.0 == 2024, 07, 13 == 최초작성
'''


# LED define
def ON():
    return 1

def OFF():
    return 0

__ON__  =  0
__OFF__ =  1

__True__  = 1
__False__ = 0



# 2024, 07, 11 추가        
def my_map(ptr, in_min, in_max, out_min, out_max):
    return (((ptr - in_min) * (out_max - out_min)) / ((in_max - in_min) + out_min)) 
