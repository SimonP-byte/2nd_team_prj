


'''
  My RPi Python I2C LIb 
  
  Hp    : 010-2402-4398
  Name  : 송 명 규
  Email : mgsong@hanmail.net
  V1.0 == 2024, 07, 16 == 최초작성  
'''



#I2C LCD LIB Call 
import RPi_I2C_driver as lcd
import smbus

lcd = lcd.lcd(0x27, 16, 2)
i2c = smbus.SMBus(1)


class My_lcd_func:    
    def __init__(self):        
        self.buf = 0
        
    def lcd_clr(self):
        lcd.clear()
    
    def cursor_home(self):
        lcd.home()
    
    def goto_xy(self, x, y):
        lcd.setCursor(x, y)
    
    def lcd_send(self, data):
        lcd.write(data) #500us
    
    def lcd_str(self, data):
        lcd.print(str(data)) #500us
    
    def lcd_tx(self, data, lens): 
        for i in range(lens):
            self.lcd_send(str(data)[i]) #500us
    
    def on_under_cursor(self):
        lcd.cursor()
    
    def off_under_cursor(self):
        lcd.noCursor()
    
    def on_box_tg_cursor(self):
        lcd.blink()
    
    def off_box_tg_cursor(self):
        lcd.noBlink()
    
    def dis_on(self):
        lcd.display()
    
    def dis_off(self):
        lcd.noDisplay()

    def move_Lf(self):
        lcd.scrollDisplayLeft()
    
    def mode_RR(self):
        lcd.scrollDisplayRight()
    
    def auto_move(self):
        lcd.autoscroll()
    
    def auto_move_off(self):
        lcd.noAutoscroll()
    
    def entry_RR(self):
        lcd.leftToRight()
    
    def entry_RL(self):
        lcd.rightToLeft()
    
    def user_font_WR(self, adder, data = []): #Adder = 0-7, data - List, Tuplef로 생성하면 됨
        lcd.createChar(adder, data)
    
    def gotoxy_str(self, x, y, data):
        self.goto_xy(x, y)
        self.lcd_str(data) #500uS
        
    def gotoxy_tx(self, x, y, data, lens):
        self.goto_xy(x, y)
        self.lcd_tx(data, lens)
        
    def gotoxy_send(self, x, y, data):
        self.goto_xy(x, y)
        self.lcd_send(data)
        
    def goto_y_clr(self, y, lens):
        for x in range(lens):
            self.goto_xy(x, y)
            self.lcd_send(' ')
            
    def goto_xy_clr(self, x, y):
            self.goto_xy(x, y)
            self.lcd_send(' ')
            
    def backlight_on(self):  #1 = ON, 0 = off
        lcd.backlight(1)
            
    def backlight_off(self):  #1 = ON, 0 = off
        lcd.backlight(0)
        
    def lcd_backlight_on(self): # 0x08 = ON, 
        i2c.write_byte(0x27, 0X08)
        
    def lcd_backlight_off(self): #0
        i2c.write_byte(0x27, 0x00)
        
        
      



    







