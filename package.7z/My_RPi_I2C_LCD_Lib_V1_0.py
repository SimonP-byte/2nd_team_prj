#I2C LCD LIB Call 
import RPi_I2C_driver
import smbus 
i2c = smbus.SMBus(1)
lcd = RPi_I2C_driver.lcd(0x27, 16, 2)

eleLogo1 = [
    0b00100,
	0b11111,
	0b00100,
	0b01010,
	0b00100,
	0b00000,
	0b11111,
	0b00100
]

eleLogo2 = [
    0b10000,
	0b11110,
	0b00000,
	0b00000,
	0b00000,
	0b00000,
	0b00000,
	0b00000
]
eleLogo3 = [
    0b00000,
	0b00100,
	0b01010,
	0b01001,
	0b00101,
	0b00010,
	0b11101,
	0b00000
]

eleLogo4 = [
    0b00000,
	0b00000,
	0b01100,
	0b00000,
	0b01000,
	0b01000,
	0b10100,
	0b00000
]

eleLogo5 = [
    0b00010,
    0b00100,
    0b00100,
    0b00010,
    0b00001,
    0b00000,
    0b00000,
    0b00000
]

eleLogo6 = [
    0b00000,
    0b00000,
    0b00011,
    0b00100,
    0b00100,
    0b11001,
    0b00010,
    0b00001
]

eleLogo7 = [
    0b00000,
    0b00000,
    0b00000,
    0b10011,
    0b10101,
    0b00100,
    0b01000,
    0b10000
]

eleLogo8 = [
    0b11000,
    0b00100,
    0b00010,
    0b00010,
    0b00100,
    0b11000,
    0b00000,
    0b00000
]

class My_lcd_func:
    def __init__(self):        
        self.buf = 0
        
    def lcd_clr(self):
        lcd.clear()
    
    def cursor_home(self):
        lcd.home()
    
    def goto_xy(self, x, y):
        lcd.setCursor(x, y)
    
    def lcd_send(self, data):
        lcd.write(data, 0)
    
    def lcd_str(self, data):
        lcd.print(str(data), 0)
    
    def lcd_tx(self, data, lens, delay):
        for i in range(lens):
            self.lcd_send(str(data)[i], delay)
    
    def on_under_cursor(self):
        lcd.cursor()
    
    def off_under_cursor(self):
        lcd.noCursor()
    
    def on_box_tg_cursor(self):
        lcd.blink()
    
    def off_box_tg_cursor(self):
        lcd.noBlink()
    
    def dis_on(self):
        lcd.display()
    
    def dis_off(self):
        lcd.noDisplay()

    def move_Lf(self):
        lcd.scrollDisplayLeft()
    
    def mode_RR(self):
        lcd.scrollDisplayRight()
    
    def auto_move(self):
        lcd.autoscroll()
    
    def auto_move_off(self):
        lcd.noAutoscroll()
    
    def entry_RR(self):
        lcd.leftToRight()
    
    def entry_RL(self):
        lcd.rightToLeft()
    
    def user_font_WR(self, adder, data):
        lcd.createChar(adder, data)
    
    def gotoxy_str(self, x, y, data):
        self.goto_xy(x, y)
        self.lcd_str(data)
        
    def gotoxy_tx(self, x, y, data, lens, delay):
        self.goto_xy(x, y)
        self.lcd_tx(data, lens, delay)
        
    def gotoxy_send(self, x, y, data, delay):
        self.goto_xy(x, y)
        self.lcd_send(data, delay)
        
    def goto_x_clr(self, y, lens, delay):
        for x in range(lens):
            self.goto_xy(x, y)
            self.lcd_send(' ', delay)
            
    def goto_xy_clr(self, x, y, delay):
            self.goto_xy(x, y)
            self.lcd_send(' ', delay)
            
    def lcd_backlight_on(self):
        lcd.backlight(1)
    
    def lcd_backlight_off(self):
        lcd.backlight(0)
            
    def backlight_on(self, data):
        i2c.write_byte(0x27, data)
    
    def backlight_off(self, data):
        i2c.write_byte(0x27, data)
